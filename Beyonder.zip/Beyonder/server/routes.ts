import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertCardSchema, insertPlayerCardSchema, insertBattleSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/users/username/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Card routes
  app.get("/api/cards", async (req, res) => {
    try {
      const cards = await storage.getAllCards();
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/cards", async (req, res) => {
    try {
      const cardData = insertCardSchema.parse(req.body);
      const card = await storage.createCard(cardData);
      res.json(card);
    } catch (error) {
      res.status(400).json({ message: "Invalid card data" });
    }
  });

  app.get("/api/cards/barcode/:barcode", async (req, res) => {
    try {
      const barcode = decodeURIComponent(req.params.barcode);
      const card = await storage.getCardByBarcode(barcode);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      res.json(card);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Player card routes
  app.get("/api/users/:userId/cards", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const cards = await storage.getPlayerCards(userId);
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/cards", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const cardData = insertPlayerCardSchema.parse({ ...req.body, userId });
      const playerCard = await storage.addPlayerCard(cardData);
      res.json(playerCard);
    } catch (error) {
      res.status(400).json({ message: "Invalid player card data" });
    }
  });

  // Battle routes
  app.post("/api/battles", async (req, res) => {
    try {
      const battleData = insertBattleSchema.parse(req.body);
      const battle = await storage.createBattle(battleData);
      res.json(battle);
    } catch (error) {
      res.status(400).json({ message: "Invalid battle data" });
    }
  });

  app.get("/api/battles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const battle = await storage.getBattle(id);
      if (!battle) {
        return res.status(404).json({ message: "Battle not found" });
      }
      res.json(battle);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/battles/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, winnerId } = req.body;
      const battle = await storage.updateBattleStatus(id, status, winnerId);
      res.json(battle);
    } catch (error) {
      res.status(400).json({ message: "Invalid battle update" });
    }
  });

  app.patch("/api/battles/:id/state", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { player1Hp, player2Hp, currentTurn } = req.body;
      const battle = await storage.updateBattleState(id, player1Hp, player2Hp, currentTurn);
      res.json(battle);
    } catch (error) {
      res.status(400).json({ message: "Invalid battle state update" });
    }
  });

  app.get("/api/battles/active", async (req, res) => {
    try {
      const battles = await storage.getActiveBattles();
      res.json(battles);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // NFC scanning route
  app.post("/api/scan", async (req, res) => {
    try {
      const { barcode, name, hp, attack, defense, speed, description, rarity, imageUrl, version, userId } = req.body;
      console.log('Scan request received:', { barcode, name, hp, attack, defense, speed, rarity, imageUrl, version, userId });
      
      // Check if card exists
      let card = await storage.getCardByBarcode(barcode);
      
      if (!card) {
        // Create new card from NFC data
        const newCard = {
          barcode,
          type: "C", // All cards are characters now
          name,
          version: version || "001",
          hp,
          attack,
          defense,
          speed,
          rarity: rarity || "common",
          description: description || `${name} character card`,
          imageUrl: imageUrl || null
        };
        
        console.log('Creating new card with data:', newCard);
        card = await storage.createCard(newCard);
      }
      
      // Add to user's collection or update quantity
      if (userId) {
        const existingPlayerCard = await storage.getPlayerCard(userId, card.id);
        if (existingPlayerCard) {
          await storage.updatePlayerCardQuantity(userId, card.id, existingPlayerCard.quantity + 1);
        } else {
          await storage.addPlayerCard({ userId, cardId: card.id, quantity: 1 });
        }
      }
      
      console.log('Final card being returned:', card);
      res.json({ card, message: "Card scanned successfully" });
    } catch (error) {
      console.error("Scan error:", error);
      res.status(500).json({ message: "Scan failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function parseBarcode(barcode: string) {
  const pattern = /^C=([^_]+)_(\d{3})$/;
  const match = barcode.match(pattern);
  
  if (match) {
    const [, name, version] = match;
    
    // Special handling for Tester card with specific stats
    if (name === 'Tester' && version === '000') {
      return {
        barcode,
        type: 'C',
        name,
        version,
        hp: 7000,
        attack: 230,
        defense: 450,
        speed: 750,
        rarity: 'legendary',
        description: 'Tester card with special abilities: Attack, Power (prevent opponent attack), Special (Armageddon - defeats opponent instantly after 5 turns)'
      };
    }
    
    // Random stats for other character cards
    const stats = getRandomStats('C');
    return {
      barcode,
      type: 'C',
      name,
      version,
      hp: stats.hp,
      attack: stats.attack,
      defense: stats.defense,
      speed: stats.speed,
      rarity: getRandomRarity(),
      description: 'A character card ready for battle'
    };
  }
  
  return null;
}

function getRandomStats(type: string): { hp: number; attack: number; defense: number; speed: number } {
  // Base character stats
  const baseStats = { 
    hp: { min: 80, max: 150 },
    attack: { min: 40, max: 100 },
    defense: { min: 30, max: 90 },
    speed: { min: 40, max: 95 }
  };
  
  return {
    hp: Math.floor(Math.random() * (baseStats.hp.max - baseStats.hp.min + 1)) + baseStats.hp.min,
    attack: Math.floor(Math.random() * (baseStats.attack.max - baseStats.attack.min + 1)) + baseStats.attack.min,
    defense: Math.floor(Math.random() * (baseStats.defense.max - baseStats.defense.min + 1)) + baseStats.defense.min,
    speed: Math.floor(Math.random() * (baseStats.speed.max - baseStats.speed.min + 1)) + baseStats.speed.min
  };
}

function getRandomRarity(): string {
  const rarities = ['common', 'common', 'common', 'rare', 'rare', 'legendary'];
  return rarities[Math.floor(Math.random() * rarities.length)];
}
