import { users, cards, playerCards, battles, type User, type InsertUser, type Card, type InsertCard, type PlayerCard, type InsertPlayerCard, type Battle, type InsertBattle } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStats(id: number, wins: number, losses: number): Promise<User>;

  // Card operations
  getCard(id: number): Promise<Card | undefined>;
  getCardByBarcode(barcode: string): Promise<Card | undefined>;
  createCard(card: InsertCard): Promise<Card>;
  getAllCards(): Promise<Card[]>;

  // Player card operations
  getPlayerCards(userId: number): Promise<(PlayerCard & { card: Card })[]>;
  addPlayerCard(playerCard: InsertPlayerCard): Promise<PlayerCard>;
  getPlayerCard(userId: number, cardId: number): Promise<PlayerCard | undefined>;
  updatePlayerCardQuantity(userId: number, cardId: number, quantity: number): Promise<PlayerCard>;

  // Battle operations
  createBattle(battle: InsertBattle): Promise<Battle>;
  getBattle(id: number): Promise<Battle | undefined>;
  updateBattleStatus(id: number, status: string, winnerId?: number): Promise<Battle>;
  updateBattleState(id: number, player1Hp: number, player2Hp: number, currentTurn: number): Promise<Battle>;
  getActiveBattles(): Promise<Battle[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cards: Map<number, Card>;
  private playerCards: Map<number, PlayerCard>;
  private battles: Map<number, Battle>;
  private currentUserId: number;
  private currentCardId: number;
  private currentPlayerCardId: number;
  private currentBattleId: number;

  constructor() {
    this.users = new Map();
    this.cards = new Map();
    this.playerCards = new Map();
    this.battles = new Map();
    this.currentUserId = 1;
    this.currentCardId = 1;
    this.currentPlayerCardId = 1;
    this.currentBattleId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      wins: 0,
      losses: 0,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStats(id: number, wins: number, losses: number): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, wins, losses };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getCard(id: number): Promise<Card | undefined> {
    return this.cards.get(id);
  }

  async getCardByBarcode(barcode: string): Promise<Card | undefined> {
    return Array.from(this.cards.values()).find(card => card.barcode === barcode);
  }

  async createCard(insertCard: InsertCard): Promise<Card> {
    const id = this.currentCardId++;
    const card: Card = { ...insertCard, id };
    console.log('Storage: Creating card with data:', card);
    this.cards.set(id, card);
    return card;
  }

  async getAllCards(): Promise<Card[]> {
    return Array.from(this.cards.values());
  }

  async getPlayerCards(userId: number): Promise<(PlayerCard & { card: Card })[]> {
    const userCards = Array.from(this.playerCards.values()).filter(pc => pc.userId === userId);
    return userCards.map(pc => {
      const card = this.cards.get(pc.cardId!);
      return { ...pc, card: card! };
    });
  }

  async addPlayerCard(insertPlayerCard: InsertPlayerCard): Promise<PlayerCard> {
    const existing = await this.getPlayerCard(insertPlayerCard.userId!, insertPlayerCard.cardId!);
    
    if (existing) {
      return await this.updatePlayerCardQuantity(
        insertPlayerCard.userId!,
        insertPlayerCard.cardId!,
        existing.quantity! + (insertPlayerCard.quantity || 1)
      );
    }

    const id = this.currentPlayerCardId++;
    const playerCard: PlayerCard = {
      ...insertPlayerCard,
      id,
      quantity: insertPlayerCard.quantity || 1,
      obtainedAt: new Date()
    };
    this.playerCards.set(id, playerCard);
    return playerCard;
  }

  async getPlayerCard(userId: number, cardId: number): Promise<PlayerCard | undefined> {
    return Array.from(this.playerCards.values()).find(
      pc => pc.userId === userId && pc.cardId === cardId
    );
  }

  async updatePlayerCardQuantity(userId: number, cardId: number, quantity: number): Promise<PlayerCard> {
    const playerCard = await this.getPlayerCard(userId, cardId);
    if (!playerCard) throw new Error("Player card not found");
    
    const updated = { ...playerCard, quantity };
    this.playerCards.set(playerCard.id, updated);
    return updated;
  }

  async createBattle(insertBattle: InsertBattle): Promise<Battle> {
    const id = this.currentBattleId++;
    const battle: Battle = {
      ...insertBattle,
      id,
      winnerId: null,
      status: "active",
      currentTurn: 1,
      player1Hp: 100,
      player2Hp: 100,
      createdAt: new Date(),
      completedAt: null
    };
    this.battles.set(id, battle);
    return battle;
  }

  async getBattle(id: number): Promise<Battle | undefined> {
    return this.battles.get(id);
  }

  async updateBattleStatus(id: number, status: string, winnerId?: number): Promise<Battle> {
    const battle = this.battles.get(id);
    if (!battle) throw new Error("Battle not found");
    
    const updated = {
      ...battle,
      status,
      winnerId: winnerId || battle.winnerId,
      completedAt: status === "completed" ? new Date() : battle.completedAt
    };
    this.battles.set(id, updated);
    return updated;
  }

  async updateBattleState(id: number, player1Hp: number, player2Hp: number, currentTurn: number): Promise<Battle> {
    const battle = this.battles.get(id);
    if (!battle) throw new Error("Battle not found");
    
    const updated = { ...battle, player1Hp, player2Hp, currentTurn };
    this.battles.set(id, updated);
    return updated;
  }

  async getActiveBattles(): Promise<Battle[]> {
    return Array.from(this.battles.values()).filter(battle => battle.status === "active");
  }
}

export const storage = new MemStorage();
