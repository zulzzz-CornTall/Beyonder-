import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  wins: integer("wins").default(0),
  losses: integer("losses").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  barcode: text("barcode").notNull().unique(),
  type: text("type").notNull(), // 'C' only (Character)
  name: text("name").notNull(),
  version: text("version").notNull(),
  hp: integer("hp").default(0),
  attack: integer("attack").default(0),
  defense: integer("defense").default(0),
  speed: integer("speed").default(0),
  rarity: text("rarity").default("common"), // common, uncommon, rare, legendary, promo
  description: text("description"),
  imageUrl: text("image_url"),
});

export const playerCards = pgTable("player_cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  cardId: integer("card_id").references(() => cards.id),
  quantity: integer("quantity").default(1),
  obtainedAt: timestamp("obtained_at").defaultNow(),
});

export const battles = pgTable("battles", {
  id: serial("id").primaryKey(),
  player1Id: integer("player1_id").references(() => users.id),
  player2Id: integer("player2_id").references(() => users.id),
  winnerId: integer("winner_id").references(() => users.id),
  status: text("status").default("active"), // active, completed, abandoned
  currentTurn: integer("current_turn").default(1),
  player1Hp: integer("player1_hp").default(100),
  player2Hp: integer("player2_hp").default(100),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
});

export const insertCardSchema = createInsertSchema(cards).pick({
  barcode: true,
  type: true,
  name: true,
  version: true,
  hp: true,
  attack: true,
  defense: true,
  speed: true,
  rarity: true,
  description: true,
});

export const insertPlayerCardSchema = createInsertSchema(playerCards).pick({
  userId: true,
  cardId: true,
  quantity: true,
});

export const insertBattleSchema = createInsertSchema(battles).pick({
  player1Id: true,
  player2Id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Card = typeof cards.$inferSelect;
export type InsertCard = z.infer<typeof insertCardSchema>;
export type PlayerCard = typeof playerCards.$inferSelect;
export type InsertPlayerCard = z.infer<typeof insertPlayerCardSchema>;
export type Battle = typeof battles.$inferSelect;
export type InsertBattle = z.infer<typeof insertBattleSchema>;
