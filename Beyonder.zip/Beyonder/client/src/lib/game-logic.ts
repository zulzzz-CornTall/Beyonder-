import type { Card } from "@shared/schema";
import { Shield, Sword, Zap, Star, User } from "lucide-react";

export function calculateDamage(attackerCard: Card | null, defenderCard: Card | null): number {
  if (!attackerCard || !defenderCard) return 0;
  
  const baseAttack = attackerCard.attack || 0;
  const baseDefense = defenderCard.defense || 0;
  
  // Apply type effectiveness
  const typeMultiplier = getTypeEffectiveness(attackerCard.type, defenderCard.type);
  
  // Calculate damage with some randomness
  const damage = Math.max(1, Math.floor((baseAttack * typeMultiplier) - (baseDefense * 0.5) + Math.random() * 10));
  
  return damage;
}

export function getTypeEffectiveness(attackerType: string, defenderType: string): number {
  // Simple type effectiveness system
  const effectiveness: Record<string, Record<string, number>> = {
    'C': { 'C': 1.0, 'P': 0.8, 'CG': 1.2, 'S': 0.9 },
    'P': { 'C': 1.2, 'P': 1.0, 'CG': 0.8, 'S': 1.1 },
    'CG': { 'C': 0.8, 'P': 1.2, 'CG': 1.0, 'S': 0.7 },
    'S': { 'C': 1.1, 'P': 0.9, 'CG': 1.3, 'S': 1.0 }
  };
  
  return effectiveness[attackerType]?.[defenderType] || 1.0;
}

export function getCardIcon(type: string) {
  switch (type) {
    case 'C': return User;
    case 'P': return Sword;
    case 'CG': return Zap;
    case 'S': return Star;
    default: return Shield;
  }
}

export function getCardTypeColor(type: string): string {
  switch (type) {
    case 'C': return 'text-electric-blue';
    case 'P': return 'text-danger-red';
    case 'CG': return 'text-warning-orange';
    case 'S': return 'text-gold-accent';
    default: return 'text-gray-400';
  }
}

export function calculateCardPower(card: Card): number {
  return (card.attack || 0) + (card.defense || 0) + (card.energy || 0);
}

export function getRandomCardStats(type: string): { attack: number; defense: number; energy: number } {
  const baseStats = {
    'C': { attack: [40, 80], defense: [30, 70], energy: [50, 90] },
    'P': { attack: [60, 100], defense: [0, 20], energy: [20, 50] },
    'CG': { attack: [0, 30], defense: [10, 40], energy: [40, 80] },
    'S': { attack: [70, 120], defense: [20, 60], energy: [60, 100] }
  };
  
  const ranges = baseStats[type as keyof typeof baseStats] || baseStats['C'];
  
  return {
    attack: Math.floor(Math.random() * (ranges.attack[1] - ranges.attack[0] + 1)) + ranges.attack[0],
    defense: Math.floor(Math.random() * (ranges.defense[1] - ranges.defense[0] + 1)) + ranges.defense[0],
    energy: Math.floor(Math.random() * (ranges.energy[1] - ranges.energy[0] + 1)) + ranges.energy[0]
  };
}

export function isCardPlayable(card: Card, currentEnergy: number): boolean {
  const energyCost = getCardEnergyCost(card);
  return currentEnergy >= energyCost;
}

export function getCardEnergyCost(card: Card): number {
  // Base energy cost based on card type and power
  const baseCost = {
    'C': 20,
    'P': 15,
    'CG': 10,
    'S': 40
  };
  
  const typeCost = baseCost[card.type as keyof typeof baseCost] || 20;
  const powerModifier = Math.floor(calculateCardPower(card) / 50);
  
  return Math.max(5, typeCost + powerModifier);
}

export function simulateAITurn(playerCards: Card[], opponentHp: number): {
  action: 'attack' | 'defend' | 'special';
  cardUsed?: Card;
  damage?: number;
} {
  // Simple AI logic
  const availableCards = playerCards.filter(card => card.type === 'C' || card.type === 'P');
  
  if (opponentHp <= 30 && Math.random() > 0.5) {
    // Try to finish with special attack
    const specialCards = playerCards.filter(card => card.type === 'S');
    if (specialCards.length > 0) {
      return {
        action: 'special',
        cardUsed: specialCards[0],
        damage: calculateDamage(specialCards[0], null)
      };
    }
  }
  
  if (Math.random() > 0.7) {
    return { action: 'defend' };
  }
  
  // Default to attack
  const attackCard = availableCards[0] || playerCards[0];
  return {
    action: 'attack',
    cardUsed: attackCard,
    damage: calculateDamage(attackCard, null)
  };
}
