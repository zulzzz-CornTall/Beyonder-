export interface NFCData {
  character: {
    name: string;
    hp: number;
    atk: number;
    def: number;
    spd: number;
    rarity: string;
    version: string;
  };
  charge: {
    name: string;
    effect: string;
  };
  special: {
    name: string;
    effect: string;
  };
}

export function parseNFC(nfcText: string): NFCData | null {
  try {
    console.log('Parsing NFC text:', nfcText);
    const lines = nfcText.split('\n').map(line => line.trim()).filter(line => line);
    console.log('Parsed lines:', lines);
    
    let characterSection = false;
    let chargeSection = false;
    let specialSection = false;
    const character: any = {};
    const charge: any = {};
    const special: any = {};
    
    for (const line of lines) {
      if (line === 'Character:') {
        characterSection = true;
        chargeSection = false;
        specialSection = false;
        continue;
      }
      
      if (line === 'Charge:') {
        characterSection = false;
        chargeSection = true;
        specialSection = false;
        continue;
      }
      
      if (line === 'Special:') {
        characterSection = false;
        chargeSection = false;
        specialSection = true;
        continue;
      }
      
      if (characterSection) {
        const [key, value] = line.split(':').map(s => s.trim());
        if (key === 'Name') character.name = value;
        if (key === 'Hp') character.hp = parseInt(value);
        if (key === 'Atk') character.atk = parseInt(value);
        if (key === 'Def') character.def = parseInt(value);
        if (key === 'SPD') character.spd = parseInt(value);
        if (key === 'Rarity') {
          // Validate rarity against allowed values
          const validRarities = ['Common', 'Uncommon', 'Rare', 'Legendary', 'Promo'];
          const normalizedRarity = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
          character.rarity = validRarities.includes(normalizedRarity) ? normalizedRarity : 'Common';
          console.log('Parsed rarity:', value, '-> normalized:', normalizedRarity, '-> final:', character.rarity);
        }
        if (key === 'Version') {
          character.version = value;
          console.log('Parsed version:', value);
        }
      }
      
      if (chargeSection) {
        const [key, value] = line.split(':').map(s => s.trim());
        if (key === 'Name') charge.name = value;
        if (key === 'Effect') charge.effect = value;
      }
      
      if (specialSection) {
        const [key, value] = line.split(':').map(s => s.trim());
        if (key === 'Name') special.name = value;
        if (key === 'Effect') special.effect = value;
      }
    }
    
    // Validate required fields
    if (!character.name || !character.hp || !character.atk || !character.def || !character.spd) {
      return null;
    }
    
    if (!charge.name || !charge.effect) {
      return null;
    }
    
    if (!special.name || !special.effect) {
      return null;
    }
    
    // Set default rarity if not specified
    if (!character.rarity) {
      character.rarity = 'Common';
    }
    
    // Set default version if not specified
    if (!character.version) {
      character.version = '001';
    }
    
    console.log('Final parsed character:', character);
    console.log('Final parsed charge:', charge);
    console.log('Final parsed special:', special);
    
    return { character, charge, special };
  } catch {
    return null;
  }
}

export function isValidNFC(nfcText: string): boolean {
  return parseNFC(nfcText) !== null;
}

export function generateNFCText(data: NFCData): string {
  return `Character:
Name: ${data.character.name}
Hp: ${data.character.hp}
Atk: ${data.character.atk}
Def: ${data.character.def}
SPD: ${data.character.spd}
Rarity: ${data.character.rarity}
Version: ${data.character.version}

Charge:
Name: ${data.charge.name}
Effect: ${data.charge.effect}

Special:
Name: ${data.special.name}
Effect: ${data.special.effect}`;
}

export function generateTestNFC(): string {
  return `Character:
Name: Tester
Hp: 7000
Atk: 230
Def: 450
SPD: 750
Rarity: Legendary
Version: 001

Charge:
Name: Lightning Strike
Effect: Deal damage based on ATK stat

Special:
Name: Thunder Storm
Effect: Deal 30% of opponent's max HP as damage`;
}

export function upgradeCharacterStats(nfcData: NFCData, statUpgrades: { hp?: number; atk?: number; def?: number; spd?: number }): NFCData {
  return {
    character: {
      name: nfcData.character.name,
      hp: nfcData.character.hp + (statUpgrades.hp || 0),
      atk: nfcData.character.atk + (statUpgrades.atk || 0),
      def: nfcData.character.def + (statUpgrades.def || 0),
      spd: nfcData.character.spd + (statUpgrades.spd || 0),
      rarity: nfcData.character.rarity,
      version: nfcData.character.version
    },
    charge: nfcData.charge,
    special: nfcData.special
  };
}

export function nfcToCard(nfcData: NFCData): any {
  const finalRarity = nfcData.character.rarity || 'Common';
  console.log('Converting NFC to card, original rarity:', nfcData.character.rarity, '-> final rarity:', finalRarity);
  
  const cardData = {
    id: Date.now(), // Temporary ID
    name: nfcData.character.name,
    type: "C",
    version: nfcData.character.version || "001",
    hp: nfcData.character.hp,
    attack: nfcData.character.atk,
    defense: nfcData.character.def,
    speed: nfcData.character.spd,
    rarity: finalRarity.toLowerCase(),
    barcode: `C=${nfcData.character.name}_${nfcData.character.version || "001"}`,
    description: `${nfcData.character.name} - Charge: ${nfcData.charge.name} (${nfcData.charge.effect})`,
    imageUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(nfcData.character.name)}&backgroundColor=transparent&eyes=eye01,eye02,eye03&mouth=mouth01,mouth02&colors=fbbf24,ef4444,3b82f6,8b5cf6,10b981`
  };
  
  console.log('Final card data being returned:', cardData);
  return cardData;
}