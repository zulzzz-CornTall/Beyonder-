import { useEffect, useRef, useState } from "react";
import { Camera, CameraOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BarcodeScannerProps {
  onScan: (barcode: string) => void;
  onError: (error: string) => void;
}

export function BarcodeScanner({ onScan, onError }: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
        };
        setStream(mediaStream);
        setIsScanning(true);
      }
    } catch (error) {
      console.error("Camera error:", error);
      onError("Camera access denied or not available");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsScanning(false);
  };

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context?.drawImage(video, 0, 0);
      
      // In a real implementation, you would use a barcode scanning library like QuaggaJS
      // For now, we'll simulate scanning with a mock result
      simulateBarcodeScan();
    }
  };

  const simulateBarcodeScan = () => {
    // Mock barcode scanning - in reality you'd use QuaggaJS or similar
    const mockBarcodes = [
      'C=DragonFire_001',
      'C=Guardian_001', 
      'C=StormBeast_001',
      'P=AttackBoost_001',
      'P=DefenseWall_001',
      'P=SpeedRush_001',
      'S=UltimateStrike_001',
      'S=MegaBlast_001'
    ];
    
    // Simulate a successful scan after a delay
    setTimeout(() => {
      const randomBarcode = mockBarcodes[Math.floor(Math.random() * mockBarcodes.length)];
      onScan(randomBarcode);
    }, 1000);
  };

  return (
    <div className="relative w-full h-full">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />
      <canvas
        ref={canvasRef}
        className="hidden"
      />
      
      {/* Scan Button */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20">
        <Button
          onClick={captureFrame}
          disabled={!isScanning}
          size="lg"
          className="bg-electric-blue hover:bg-electric-blue/80 text-white rounded-full w-16 h-16"
        >
          <Camera size={24} />
        </Button>
      </div>

      {/* Camera Controls */}
      <div className="absolute top-4 right-4 z-20">
        <Button
          onClick={isScanning ? stopCamera : startCamera}
          variant="outline"
          size="sm"
          className="bg-black/50 border-white/20 text-white hover:bg-black/70"
        >
          {isScanning ? <CameraOff size={16} /> : <Camera size={16} />}
        </Button>
      </div>
    </div>
  );
}
