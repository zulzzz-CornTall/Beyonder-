import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Zap, Smartphone, Scan, AlertCircle } from "lucide-react";

interface NFCScannerProps {
  onScan: (nfcText: string) => void;
  onError: (error: string) => void;
}

export function NFCScanner({ onScan, onError }: NFCScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [nfcSupported, setNfcSupported] = useState(false);

  useEffect(() => {
    // Check if NFC is supported
    if ('NDEFReader' in window) {
      setNfcSupported(true);
    } else {
      setNfcSupported(false);
    }
  }, []);

  const handleNFCScan = async () => {
    if (!nfcSupported) {
      onError("NFC is not supported on this device");
      return;
    }

    try {
      setIsScanning(true);
      // @ts-ignore - NDEFReader is experimental
      const ndef = new NDEFReader();
      
      await ndef.scan();
      
      ndef.addEventListener("reading", ({ message }) => {
        const decoder = new TextDecoder();
        let nfcData = "";
        
        for (const record of message.records) {
          if (record.recordType === "text") {
            nfcData += decoder.decode(record.data);
          }
        }
        
        if (nfcData) {
          onScan(nfcData);
        } else {
          onError("No text data found on NFC tag");
        }
        
        setIsScanning(false);
      });
      
    } catch (error) {
      console.error("NFC scan error:", error);
      onError("Failed to scan NFC tag. Please try again.");
      setIsScanning(false);
    }
  };

  return (
    <div className="flex flex-col items-center space-y-6">
      {/* NFC Scan Button */}
      <Card className="w-full max-w-md bg-gray-900 border-gray-700">
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
              <Smartphone className="w-10 h-10 text-white" />
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">NFC Scanner</h3>
              <p className="text-sm text-gray-300 mb-4">
                {nfcSupported 
                  ? "Hold your NFC card near your device to scan" 
                  : "NFC not supported on this device"
                }
              </p>
            </div>
            
            <Button
              onClick={handleNFCScan}
              disabled={!nfcSupported || isScanning}
              className="w-full bg-blue-600 hover:bg-blue-700 py-3"
            >
              {isScanning ? (
                <>
                  <Zap className="w-5 h-5 mr-2 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Scan className="w-5 h-5 mr-2" />
                  Scan NFC Card
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Device Requirements */}
      {!nfcSupported && (
        <Card className="w-full max-w-md bg-yellow-900 border-yellow-600">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <AlertCircle className="w-6 h-6 text-yellow-400" />
              <div>
                <h3 className="text-lg font-semibold text-yellow-300 mb-2">Device Requirements</h3>
                <p className="text-sm text-yellow-200">
                  NFC scanning requires Chrome or Edge on Android devices. 
                  Desktop browsers and iOS don't support Web NFC.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Physical Card Only Notice */}
      <Card className="w-full max-w-md bg-purple-900 border-purple-600">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-purple-300 mb-2">Physical Cards Only</h3>
            <p className="text-sm text-purple-200">
              This scanner only works with physical NFC cards. 
              Scanned cards will be automatically added to your collection.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}