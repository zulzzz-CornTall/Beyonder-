import { Button } from "@/components/ui/button";
import { ArrowLeft, Settings } from "lucide-react";
import { useLocation } from "wouter";
import logoPath from "@assets/Tak berjudul314_20250707132705_1751875827655.png";

interface HeaderProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  backUrl?: string;
  showUser?: boolean;
  user?: {
    username: string;
    wins: number;
    cardCount: number;
  };
}

export function Header({ 
  title, 
  subtitle, 
  showBack = false, 
  backUrl = "/", 
  showUser = false,
  user 
}: HeaderProps) {
  const [, setLocation] = useLocation();

  if (showUser && user) {
    // Home page style header
    return (
      <header className="bg-game-dark border-b border-fire-red/30 px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <img 
                src={logoPath} 
                alt="BEYONDER Logo" 
                className="h-12 w-auto object-contain"
              />
            </div>
            <div className="border-l border-fire-red/30 pl-4">
              <p className="text-xs text-gray-400 uppercase tracking-wider">Arena Mode</p>
              <p className="text-xs text-flame-yellow font-medium">Welcome, {user.username}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-center">
              <p className="text-xs text-gray-400 uppercase">Wins</p>
              <p className="font-orbitron font-bold text-flame-yellow">{user.wins}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400 uppercase">Cards</p>
              <p className="font-orbitron font-bold text-fire-orange">{user.cardCount}</p>
            </div>
            <Button variant="ghost" size="sm" className="w-8 h-8 rounded-full bg-game-accent hover:bg-fire-red/20 border border-fire-red/20">
              <Settings className="h-4 w-4 text-fire-red" />
            </Button>
          </div>
        </div>
      </header>
    );
  }

  // Battle/page style header
  return (
    <div className="fire-gradient p-6">
      <div className="flex items-center justify-between">
        {showBack ? (
          <Button 
            onClick={() => setLocation(backUrl)}
            variant="ghost" 
            size="sm" 
            className="w-10 h-10 rounded-full bg-black/70 hover:bg-black/90 border border-flame-yellow/30"
          >
            <ArrowLeft className="text-flame-yellow" size={20} />
          </Button>
        ) : (
          <div className="w-10 h-10"></div>
        )}
        
        <div className="text-center">
          {title && (
            <h1 className="font-orbitron font-bold text-xl text-white drop-shadow-lg">
              {title}
            </h1>
          )}
          {subtitle && (
            <p className="text-sm text-gray-200 font-medium">
              {subtitle}
            </p>
          )}
        </div>
        <div className="w-10 h-10"></div>
      </div>
    </div>
  );
}