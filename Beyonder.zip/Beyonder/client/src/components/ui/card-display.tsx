import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Flame, 
  Shield, 
  Zap, 
  Star, 
  Sword, 
  Heart,
  User,
  Activity
} from "lucide-react";
import type { Card as CardType } from "@shared/schema";

interface CardDisplayProps {
  card: CardType;
  size?: "small" | "medium" | "large";
  showQuantity?: number;
  showStats?: boolean;
  className?: string;
}

export function CardDisplay({ 
  card, 
  size = "medium", 
  showQuantity, 
  showStats = true,
  className = ""
}: CardDisplayProps) {
  const getCardIcon = (type: string) => {
    switch (type) {
      case "C": return <User className="text-electric-blue" size={size === "large" ? 32 : 24} />;
      case "P": return <Flame className="text-purple-glow" size={size === "large" ? 32 : 24} />;
      case "S": return <Star className="text-gold-accent" size={size === "large" ? 32 : 24} />;
      default: return <Shield className="text-gray-400" size={size === "large" ? 32 : 24} />;
    }
  };

  const getCardTypeLabel = (type: string) => {
    switch (type) {
      case "C": return "Character";
      case "P": return "Power";
      case "S": return "Special";
      default: return "Unknown";
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case "common": return "bg-gray-600";
      case "uncommon": return "bg-green-600";
      case "rare": return "bg-blue-600";
      case "legendary": return "bg-purple-600";
      case "promo": return "bg-yellow-600";
      default: return "bg-gray-600";
    }
  };

  const cardSizeClasses = {
    small: "w-24 h-32",
    medium: "w-32 h-44",
    large: "w-40 h-56"
  };

  return (
    <div className={`relative ${cardSizeClasses[size]} ${className}`}>
      <Card className="card-holographic h-full hover:scale-105 transition-transform">
        <CardContent className="p-3 h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary" className={`text-xs ${getRarityColor(card.rarity)} text-white`}>
              {card.rarity}
            </Badge>
            {showQuantity && (
              <Badge variant="outline" className="text-xs">
                x{showQuantity}
              </Badge>
            )}
          </div>

          {/* Card Image or Icon */}
          <div className="flex-1 flex items-center justify-center mb-2">
            {card.imageUrl ? (
              <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-800 flex items-center justify-center">
                <img 
                  src={card.imageUrl} 
                  alt={card.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    console.error('Image failed to load:', card.imageUrl);
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            ) : (
              <div className="w-16 h-16 flex items-center justify-center">
                {getCardIcon(card.type)}
              </div>
            )}
          </div>

          {/* Card Info */}
          <div className="text-center space-y-1">
            <h3 className={`font-orbitron font-bold ${size === "large" ? "text-base" : "text-sm"} text-white`}>
              {card.name}
            </h3>
            <p className="text-xs text-gray-400">{getCardTypeLabel(card.type)}</p>
            <Badge variant="outline" className="text-xs">
              v{card.version}
            </Badge>
          </div>

          {/* Stats */}
          {showStats && (
            <div className="mt-2 space-y-1">
              {card.hp > 0 && (
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1">
                    <Heart className="text-neon-green" size={12} />
                    <span>HP</span>
                  </div>
                  <span className="font-orbitron font-bold text-neon-green">{card.hp}</span>
                </div>
              )}
              {card.attack > 0 && (
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1">
                    <Sword className="text-danger-red" size={12} />
                    <span>ATK</span>
                  </div>
                  <span className="font-orbitron font-bold text-danger-red">{card.attack}</span>
                </div>
              )}
              {card.defense > 0 && (
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1">
                    <Shield className="text-electric-blue" size={12} />
                    <span>DEF</span>
                  </div>
                  <span className="font-orbitron font-bold text-electric-blue">{card.defense}</span>
                </div>
              )}
              {card.speed > 0 && (
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1">
                    <Activity className="text-warning-orange" size={12} />
                    <span>SPD</span>
                  </div>
                  <span className="font-orbitron font-bold text-warning-orange">{card.speed}</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
