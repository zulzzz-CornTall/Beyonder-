// NFC Web API Type Definitions
declare global {
  interface Window {
    NDEFReader: typeof NDEFReader;
    NDEFWriter: typeof NDEFWriter;
  }

  class NDEFReader extends EventTarget {
    constructor();
    scan(options?: { signal?: AbortSignal }): Promise<void>;
    addEventListener(
      type: 'reading',
      listener: (event: NDEFReadingEvent) => void,
      options?: boolean | AddEventListenerOptions
    ): void;
    addEventListener(
      type: 'readingerror',
      listener: (event: Event) => void,
      options?: boolean | AddEventListenerOptions
    ): void;
    addEventListener(
      type: string,
      listener: EventListener,
      options?: boolean | AddEventListenerOptions
    ): void;
  }

  class NDEFWriter {
    constructor();
    write(
      message: NDEFMessage | string,
      options?: { overwrite?: boolean; signal?: AbortSignal }
    ): Promise<void>;
  }

  interface NDEFReadingEvent extends Event {
    serialNumber: string;
    message: NDEFMessage;
  }

  interface NDEFMessage {
    records: NDEFRecord[];
  }

  interface NDEFRecord {
    recordType: string;
    mediaType?: string;
    id?: string;
    data?: any;
    encoding?: string;
    lang?: string;
  }

  interface Navigator {
    permissions: {
      query(descriptor: { name: string }): Promise<PermissionStatus>;
    };
  }
}

export {};