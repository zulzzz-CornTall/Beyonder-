import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/ui/header";
import { 
  Zap, 
  Sword, 
  Users, 
  Globe, 
  Layers, 
  QrCode, 
  Trophy, 
  Settings 
} from "lucide-react";

export default function Home() {
  // Mock user data for now
  const mockUser = {
    id: 1,
    username: "Player1", 
    wins: 0,
    losses: 0,
    cardCount: 0
  };

  const { data: recentGames } = useQuery({
    queryKey: ['/api/battles/recent'],
    enabled: false // Mock data for now
  });

  const mockRecentGames: any[] = [];

  return (
    <div className="min-h-screen bg-game-dark text-white">
      <Header showUser={true} user={mockUser} />

      {/* Main Content */}
      <main className="p-4 space-y-6">
        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Link href="/scanner">
            <div className="fire-gradient p-[2px] rounded-xl hover:scale-105 transition-transform cursor-pointer">
              <Card className="bg-game-secondary rounded-lg">
                <CardContent className="p-4 text-center">
                  <QrCode className="text-3xl text-flame-yellow mb-2 mx-auto" size={48} />
                  <h3 className="font-orbitron font-bold text-sm fire-text-gradient">SCAN CARD</h3>
                  <p className="text-xs text-gray-400 mt-1">NFC scanning</p>
                </CardContent>
              </Card>
            </div>
          </Link>
          <Link href="/matchmaking">
            <div className="fire-gradient p-[2px] rounded-xl hover:scale-105 transition-transform cursor-pointer">
              <Card className="bg-game-secondary rounded-lg">
                <CardContent className="p-4 text-center">
                  <Sword className="text-3xl text-fire-red mb-2 mx-auto" size={48} />
                  <h3 className="font-orbitron font-bold text-sm fire-text-gradient">BATTLE</h3>
                  <p className="text-xs text-gray-400 mt-1">Find opponent</p>
                </CardContent>
              </Card>
            </div>
          </Link>
        </div>



        {/* Game Modes */}
        <Card className="bg-game-secondary border border-fire-red/20">
          <CardContent className="p-4">
            <h2 className="font-orbitron font-bold text-lg mb-4 fire-text-gradient">GAME MODES</h2>
            <div className="space-y-3">
              <Link href="/battle">
                <Button variant="ghost" className="w-full bg-game-accent rounded-lg p-3 flex items-center justify-between hover:bg-fire-red/10 h-auto border border-fire-red/20">
                  <div className="flex items-center space-x-3">
                    <Users className="text-fire-orange" size={20} />
                    <div className="text-left">
                      <h3 className="font-semibold text-white">Local Battle</h3>
                      <p className="text-xs text-gray-400">2 players, 1 device</p>
                    </div>
                  </div>
                  <span className="text-flame-yellow">→</span>
                </Button>
              </Link>
              <Link href="/matchmaking">
                <Button variant="ghost" className="w-full bg-game-accent rounded-lg p-3 flex items-center justify-between hover:bg-fire-red/10 h-auto border border-fire-red/20">
                  <div className="flex items-center space-x-3">
                    <Globe className="text-flame-yellow" size={20} />
                    <div className="text-left">
                      <h3 className="font-semibold text-white">Online Battle</h3>
                      <p className="text-xs text-gray-400">Find random opponent</p>
                    </div>
                  </div>
                  <span className="text-flame-yellow">→</span>
                </Button>
              </Link>
              <Link href="/cards">
                <Button variant="ghost" className="w-full bg-game-accent rounded-lg p-3 flex items-center justify-between hover:bg-fire-red/10 h-auto border border-fire-red/20">
                  <div className="flex items-center space-x-3">
                    <Layers className="text-fire-red" size={20} />
                    <div className="text-left">
                      <h3 className="font-semibold text-white">My Cards</h3>
                      <p className="text-xs text-gray-400">View scanned cards</p>
                    </div>
                  </div>
                  <span className="text-flame-yellow">→</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-game-secondary border border-fire-red/20">
          <CardContent className="p-4">
            <h2 className="font-orbitron font-bold text-lg mb-4 fire-text-gradient">RECENT ACTIVITY</h2>
            <div className="space-y-3">
              {mockRecentGames.length === 0 ? (
                <div className="text-center py-8">
                  <Trophy className="text-gray-500 mb-2 mx-auto" size={32} />
                  <p className="text-gray-400 text-sm">No battles yet</p>
                  <p className="text-gray-500 text-xs">Start scanning cards and battle!</p>
                </div>
              ) : (
                mockRecentGames.map((game) => (
                  <div key={game.id} className="flex items-center space-x-3 p-2 rounded-lg bg-game-accent border border-fire-red/10">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      game.result === 'victory' ? 'bg-fire-orange' : 'bg-dark-red'
                    }`}>
                      <Trophy className="text-xs text-white" size={16} />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">
                        {game.result === 'victory' ? 'Victory' : 'Defeat'} vs {game.opponent}
                      </p>
                      <p className="text-xs text-gray-400">{game.time}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-orbitron text-flame-yellow">+{game.xp} XP</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
