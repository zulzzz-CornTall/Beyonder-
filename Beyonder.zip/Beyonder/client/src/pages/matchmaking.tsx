import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Header } from "@/components/ui/header";
import { 
  Users, 
  ArrowLeft,
  Gamepad2,
  Globe,
  Plus,
  Key
} from "lucide-react";

export default function Matchmaking() {
  const [, setLocation] = useLocation();
  const [battleMode, setBattleMode] = useState<"select" | "local" | "online" | "create" | "join">("select");
  const [roomCode, setRoomCode] = useState("");

  const handleLocalBattle = () => {
    setLocation("/battle?mode=local");
  };

  const handleCreateRoom = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    setRoomCode(code);
    setBattleMode("create");
  };

  const handleJoinRoom = () => {
    if (roomCode.length >= 4) {
      setLocation(`/battle?mode=online&room=${roomCode}`);
    }
  };

  return (
    <div className="min-h-screen bg-game-dark text-white">
      <Header 
        title="BATTLE MODE"
        subtitle="Choose your battle type"
        showBack={true}
        backUrl={battleMode === "select" ? "/" : "#"}
      />

      <div className="p-6 space-y-6">
        {battleMode === "select" && (
          <>
            {/* Local Battle */}
            <Card className="bg-game-secondary border border-fire-red/20 hover:border-fire-orange transition-colors">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Gamepad2 className="text-fire-orange" size={20} />
                  Local Battle
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300 text-sm">
                  Battle with a friend using the same device. Each player scans their card, then take turns side by side.
                </p>
                <Button 
                  onClick={handleLocalBattle}
                  className="w-full fire-gradient hover:opacity-90 h-12 text-white font-bold"
                >
                  <Gamepad2 className="mr-2" size={20} />
                  Start Local Battle
                </Button>
              </CardContent>
            </Card>

            {/* Online Battle Options */}
            <Card className="bg-game-secondary border border-fire-red/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Globe className="text-flame-yellow" size={20} />
                  Online Battle
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300 text-sm">
                  Battle with players online using room codes or automatic matchmaking.
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    onClick={handleCreateRoom}
                    variant="outline"
                    className="border-fire-orange text-fire-orange hover:bg-fire-orange/20"
                  >
                    <Plus className="mr-2" size={16} />
                    Create Room
                  </Button>
                  <Button 
                    onClick={() => setBattleMode("join")}
                    variant="outline"
                    className="border-flame-yellow text-flame-yellow hover:bg-flame-yellow/20"
                  >
                    <Key className="mr-2" size={16} />
                    Join Room
                  </Button>
                </div>
                
                <div className="text-center text-gray-400 text-sm">or</div>
                
                <Button 
                  onClick={() => setBattleMode("online")}
                  className="w-full bg-gradient-to-r from-dark-red to-fire-red hover:from-dark-red/80 hover:to-fire-red/80 h-12 text-white font-bold"
                >
                  <Users className="mr-2" size={20} />
                  Find Random Opponent
                </Button>
              </CardContent>
            </Card>
          </>
        )}

        {battleMode === "create" && (
          <Card className="bg-gray-900 border-green-700 border-2">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Plus className="text-green-400" size={20} />
                Room Created
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-orbitron font-bold text-green-400 mb-2">
                  {roomCode}
                </div>
                <p className="text-gray-300 text-sm">
                  Share this code with your friend to join the battle
                </p>
              </div>
              
              <Badge variant="default" className="w-full justify-center bg-green-600 py-2">
                Waiting for opponent...
              </Badge>
              
              <Button 
                onClick={() => navigator.clipboard.writeText(roomCode)}
                variant="outline"
                className="w-full border-green-600 text-green-400 hover:bg-green-900/20"
              >
                Copy Room Code
              </Button>
            </CardContent>
          </Card>
        )}

        {battleMode === "join" && (
          <Card className="bg-gray-900 border-blue-700 border-2">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Key className="text-blue-400" size={20} />
                Join Battle Room
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-gray-300 text-sm">Enter Room Code:</label>
                <Input
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  placeholder="Enter 6-character code"
                  className="bg-gray-800 border-gray-600 text-white text-center text-lg font-orbitron"
                  maxLength={6}
                />
              </div>
              
              <Button 
                onClick={handleJoinRoom}
                disabled={roomCode.length < 4}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700"
              >
                Join Battle Room
              </Button>
            </CardContent>
          </Card>
        )}

        {battleMode === "online" && (
          <Card className="bg-gray-900 border-purple-700 border-2">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="text-purple-400" size={20} />
                Online Matchmaking
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-300 text-sm text-center">
                This feature will be available soon! For now, use Local Battle or Room Codes.
              </p>
              
              <Badge variant="outline" className="w-full justify-center border-yellow-600 text-yellow-400 py-2">
                Coming Soon
              </Badge>
            </CardContent>
          </Card>
        )}

        {/* Battle Tips */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Gamepad2 className="text-yellow-400" size={20} />
              Battle Tips
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-electric-blue rounded-full"></div>
                Scan your character card before battle starts
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-electric-blue rounded-full"></div>
                Higher speed determines who goes first
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-electric-blue rounded-full"></div>
                Use Power and Special abilities strategically
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 bg-electric-blue rounded-full"></div>
                Win battles to earn upgrade points
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}