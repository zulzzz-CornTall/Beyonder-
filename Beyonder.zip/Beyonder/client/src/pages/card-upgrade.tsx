import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Header } from "@/components/ui/header";
import { ArrowLeft, TrendingUp, Zap, Shield, Activity, Gauge, AlertCircle, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { parseNFC, generateNFCText, upgradeCharacterStats, nfcToCard } from "@/lib/nfc-utils";
import type { NFCData } from "@/lib/nfc-utils";

export default function CardUpgrade() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentCard, setCurrentCard] = useState<NFCData | null>(null);
  const [upgradedCard, setUpgradedCard] = useState<NFCData | null>(null);
  const [upgradePoints, setUpgradePoints] = useState(5); // Points available for upgrade
  const [upgrades, setUpgrades] = useState({ hp: 0, atk: 0, def: 0, spd: 0 });
  const [isWritingNFC, setIsWritingNFC] = useState(false);
  const [nfcSupport, setNfcSupport] = useState({ read: false, write: false, secure: false });
  const [forceNFC, setForceNFC] = useState(false);

  // Check NFC support on component mount
  useEffect(() => {
    const checkNFCSupport = () => {
      const hasNDEFReader = 'NDEFReader' in window;
      const hasNDEFWriter = 'NDEFWriter' in window;
      const isSecureContext = window.isSecureContext;
      
      console.log('NFC Support Check:', {
        NDEFReader: hasNDEFReader,
        NDEFWriter: hasNDEFWriter,
        secureContext: isSecureContext,
        userAgent: navigator.userAgent
      });
      
      setNfcSupport({
        read: hasNDEFReader && isSecureContext,
        write: hasNDEFWriter && isSecureContext,
        secure: isSecureContext
      });
    };
    
    checkNFCSupport();
  }, []);

  const handleNFCRead = async () => {
    if (!forceNFC) {
      if (!('NDEFReader' in window)) {
        toast({
          title: "NFC Not Supported",
          description: "Your device doesn't support NFC reading.",
          variant: "destructive"
        });
        return;
      }

      // Check if we're in a secure context (HTTPS)
      if (!window.isSecureContext) {
        toast({
          title: "Secure Context Required",
          description: "NFC reading requires HTTPS. Please use a secure connection.",
          variant: "destructive"
        });
        return;
      }
    }

    try {
      const ndef = new NDEFReader();
      await ndef.scan();
      
      toast({
        title: "Ready to Scan",
        description: "Hold your NFC card near the device to read it.",
      });
      
      ndef.addEventListener("reading", ({ message }) => {
        const decoder = new TextDecoder();
        let nfcText = "";
        
        for (const record of message.records) {
          if (record.recordType === "text") {
            nfcText += decoder.decode(record.data);
          }
        }
        
        const nfcData = parseNFC(nfcText);
        if (nfcData) {
          setCurrentCard(nfcData);
          toast({
            title: "Card Read Successfully",
            description: `${nfcData.character.name} is ready for upgrade!`,
          });
        } else {
          toast({
            title: "Invalid Card",
            description: "The NFC card format is invalid.",
            variant: "destructive"
          });
        }
      });
    } catch (error) {
      console.error("NFC Read Error:", error);
      let errorMessage = "Failed to read NFC card. Please try again.";
      
      // Handle specific error types
      if (error instanceof DOMException) {
        switch (error.name) {
          case 'NotAllowedError':
            errorMessage = "NFC access denied. Please allow NFC permissions.";
            break;
          case 'NotSupportedError':
            errorMessage = "NFC reading is not supported on this device.";
            break;
          case 'InvalidStateError':
            errorMessage = "NFC is not available. Please check if NFC is enabled.";
            break;
          case 'AbortError':
            errorMessage = "NFC operation was cancelled.";
            break;
          default:
            errorMessage = `NFC Error: ${error.message}`;
        }
      }
      
      toast({
        title: "NFC Read Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  const handleUpgrade = (stat: keyof typeof upgrades, increment: number) => {
    const newUpgrades = { ...upgrades };
    const currentValue = newUpgrades[stat];
    const newValue = currentValue + increment;
    
    const currentTotal = Object.values(upgrades).reduce((sum, val) => sum + val, 0);
    const newTotal = currentTotal + increment;
    
    if (newValue >= 0 && newTotal <= upgradePoints) {
      newUpgrades[stat] = newValue;
      setUpgrades(newUpgrades);
      
      if (currentCard) {
        const upgraded = upgradeCharacterStats(currentCard, {
          hp: newUpgrades.hp * 100,
          atk: newUpgrades.atk * 10,
          def: newUpgrades.def * 10,
          spd: newUpgrades.spd * 10
        });
        setUpgradedCard(upgraded);
      }
    }
  };

  const handleWriteNFC = async () => {
    if (!upgradedCard) {
      toast({
        title: "No Upgrades",
        description: "Please allocate upgrade points first.",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsWritingNFC(true);
      
      const nfcText = generateNFCText(upgradedCard);
      console.log("Attempting to write NFC data:", nfcText);
      
      toast({
        title: "Starting NFC Write",
        description: "Please bring your NFC card close to your device...",
      });
      
      const ndef = new NDEFWriter();
      
      // Write the NFC data
      await ndef.write({
        records: [{ 
          recordType: "text", 
          data: nfcText,
          encoding: "utf-8"
        }]
      });
      
      toast({
        title: "Card Upgraded Successfully!",
        description: `${upgradedCard.character.name} has been upgraded and written to NFC.`,
      });
      
      // Reset state
      setCurrentCard(null);
      setUpgradedCard(null);
      setUpgrades({ hp: 0, atk: 0, def: 0, spd: 0 });
      setIsWritingNFC(false);
      
    } catch (error) {
      console.error("NFC Write Error Details:", error);
      console.error("Error type:", typeof error);
      console.error("Error constructor:", error.constructor.name);
      console.error("Error message:", error.message);
      console.error("Error stack:", error.stack);
      
      let errorMessage = "Failed to write upgraded card to NFC. Please try again.";
      let detailedError = `Error: ${error.message}`;
      
      // Handle specific error types
      if (error instanceof DOMException) {
        detailedError = `DOMException: ${error.name} - ${error.message}`;
        switch (error.name) {
          case 'NotAllowedError':
            errorMessage = "NFC access denied. Please allow NFC permissions and make sure NFC is enabled on your device.";
            break;
          case 'NotSupportedError':
            errorMessage = "NFC writing is not supported on this device or browser.";
            break;
          case 'NotReadableError':
            errorMessage = "NFC tag is not readable. Please try a different tag.";
            break;
          case 'NetworkError':
            errorMessage = "NFC connection failed. Make sure the NFC tag is close to your device.";
            break;
          case 'InvalidStateError':
            errorMessage = "NFC is not available. Please check if NFC is enabled in device settings.";
            break;
          case 'AbortError':
            errorMessage = "NFC operation was cancelled.";
            break;
          case 'SecurityError':
            errorMessage = "NFC access blocked by security policy. Make sure you're using HTTPS.";
            break;
          case 'TypeError':
            errorMessage = "NFC API not available. Your browser may not support Web NFC.";
            break;
          default:
            errorMessage = `NFC Error (${error.name}): ${error.message}`;
        }
      } else if (error instanceof TypeError) {
        errorMessage = "NFC API not available. Your browser may not support Web NFC.";
        detailedError = `TypeError: ${error.message}`;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: "NFC Write Error",
        description: errorMessage,
        variant: "destructive"
      });
      
      // Show detailed error for debugging
      console.log("Showing detailed error to user:", detailedError);
      setTimeout(() => {
        toast({
          title: "Debug Info",
          description: detailedError,
          variant: "destructive"
        });
      }, 2000);
      
      setIsWritingNFC(false);
    }
  };



  const usedPoints = Object.values(upgrades).reduce((sum, val) => sum + val, 0);

  const requestNFCPermissions = async () => {
    try {
      toast({
        title: "Requesting NFC Permissions",
        description: "Please allow NFC access when prompted...",
      });

      // Try to request permissions via NFC scan (this usually triggers permission prompt)
      if ('NDEFReader' in window) {
        const ndef = new NDEFReader();
        await ndef.scan();
        
        toast({
          title: "NFC Permissions Granted",
          description: "NFC is now enabled. You can now write to NFC cards.",
        });
      } else {
        throw new Error("NFC not supported");
      }
    } catch (error) {
      console.error("NFC Permission Error:", error);
      toast({
        title: "Permission Error",
        description: "Failed to enable NFC. Make sure NFC is enabled in device settings.",
        variant: "destructive"
      });
    }
  };

  const testNFCCapabilities = async () => {
    toast({
      title: "Testing NFC Capabilities",
      description: "Checking what NFC features are available...",
    });

    const results = [];
    
    // Test browser info
    const userAgent = navigator.userAgent;
    const browserInfo = getBrowserInfo(userAgent);
    results.push(`Browser: ${browserInfo}`);
    
    // Test basic NFC support
    if ('NDEFReader' in window) {
      results.push("✓ NDEFReader available");
    } else {
      results.push("✗ NDEFReader NOT available");
    }
    
    if ('NDEFWriter' in window) {
      results.push("✓ NDEFWriter available");
    } else {
      results.push("✗ NDEFWriter NOT available");
    }
    
    if (window.isSecureContext) {
      results.push("✓ Secure context (HTTPS)");
    } else {
      results.push("✗ NOT secure context");
    }
    
    // Test permissions
    try {
      const permissionStatus = await navigator.permissions.query({name: 'nfc'});
      results.push(`✓ NFC permission: ${permissionStatus.state}`);
    } catch (error) {
      results.push("✗ NFC permission check failed");
    }
    
    // Test creating NDEFWriter
    try {
      const writer = new NDEFWriter();
      results.push("✓ NDEFWriter creation successful");
    } catch (error) {
      results.push(`✗ NDEFWriter creation failed: ${error.message}`);
    }
    
    console.log("NFC Capabilities Test Results:", results);
    
    toast({
      title: "NFC Test Results",
      description: results.slice(0, 3).join(", "),
    });
    
    // Show detailed results
    setTimeout(() => {
      toast({
        title: "Detailed Results",
        description: results.slice(3).join(", "),
      });
    }, 3000);
  };

  const getBrowserInfo = (userAgent: string) => {
    if (userAgent.includes('Chrome')) return 'Chrome';
    if (userAgent.includes('Firefox')) return 'Firefox';
    if (userAgent.includes('Safari')) return 'Safari';
    if (userAgent.includes('Edge')) return 'Edge';
    if (userAgent.includes('Opera')) return 'Opera';
    return 'Unknown';
  };

  const getRarityBadgeColor = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case 'common': return 'bg-gray-600';
      case 'uncommon': return 'bg-green-600';
      case 'rare': return 'bg-blue-600';
      case 'legendary': return 'bg-purple-600';
      case 'promo': return 'bg-yellow-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-game-dark text-white">
      <Header 
        title="CARD UPGRADE"
        subtitle="Enhance your character's stats"
        showBack={true}
        backUrl="/"
      />

      <div className="p-6 space-y-6">
        {/* NFC Status Display */}
        <Card className="bg-game-secondary border border-fire-red/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertCircle className="text-flame-yellow" size={20} />
              NFC Support Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">NFC Reading (NDEFReader):</span>
              <Badge variant={('NDEFReader' in window) ? "default" : "destructive"}>
                {('NDEFReader' in window) ? "Available" : "Not Available"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">NFC Writing (NDEFWriter):</span>
              <Badge variant={('NDEFWriter' in window) ? "default" : "destructive"}>
                {('NDEFWriter' in window) ? "Available" : "Not Available"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Secure Context (HTTPS):</span>
              <Badge variant={nfcSupport.secure ? "default" : "destructive"}>
                {nfcSupport.secure ? "Yes" : "No"}
              </Badge>
            </div>
            {(!nfcSupport.read || !nfcSupport.write || !nfcSupport.secure) && (
              <div className="space-y-2 mt-2">
                <p className="text-xs text-yellow-400">
                  ⚠️ NFC features require a supported device and HTTPS connection
                </p>
                
                {/* Browser compatibility info */}
                <div className="p-2 bg-gray-800 rounded text-xs">
                  <p className="text-white font-semibold mb-1">Web NFC Browser Support:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <p className="text-gray-400 font-semibold">NFC Reading:</p>
                      <p className="text-green-400">✓ Chrome Android 81+</p>
                      <p className="text-green-400">✓ Edge Android 81+</p>
                      <p className="text-green-400">✓ Samsung Internet 13+</p>
                      <p className="text-red-400">✗ Safari/iOS</p>
                      <p className="text-red-400">✗ Firefox</p>
                      <p className="text-red-400">✗ Desktop browsers</p>
                    </div>
                    <div>
                      <p className="text-gray-400 font-semibold">NFC Writing:</p>
                      <p className="text-green-400">✓ Chrome Android 83+</p>
                      <p className="text-green-400">✓ Edge Android 83+</p>
                      <p className="text-yellow-400">? Samsung Internet</p>
                      <p className="text-red-400">✗ Safari/iOS</p>
                      <p className="text-red-400">✗ Firefox</p>
                      <p className="text-red-400">✗ Desktop browsers</p>
                    </div>
                  </div>
                  <p className="text-yellow-400 mt-2">Your device may support reading but not writing</p>
                </div>
                
                <div className="flex items-center justify-between p-2 bg-gray-800 rounded">
                  <div className="flex items-center gap-2">
                    <Settings className="text-orange-400" size={16} />
                    <span className="text-sm text-gray-300">Force NFC (Skip Checks)</span>
                  </div>
                  <Switch
                    checked={forceNFC}
                    onCheckedChange={setForceNFC}
                  />
                </div>
                {forceNFC && (
                  <p className="text-xs text-orange-400">
                    ⚠️ Force mode enabled - NFC operations will attempt even if unsupported
                  </p>
                )}
                <Button 
                  onClick={testNFCCapabilities}
                  variant="outline"
                  size="sm"
                  className="mt-2 w-full"
                >
                  Test NFC Capabilities
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* NFC Read Section */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="text-green-400" size={20} />
              Load Card for Upgrade
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button 
                onClick={handleNFCRead} 
                className="bg-blue-600 hover:bg-blue-700 flex-1"
              >
                Read NFC Card
              </Button>

            </div>
            
            {currentCard && (
              <div className="mt-4 p-4 bg-gray-800 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-2">{currentCard.character.name}</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Activity className="text-red-400" size={16} />
                    <span>HP: {currentCard.character.hp}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="text-yellow-400" size={16} />
                    <span>ATK: {currentCard.character.atk}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="text-blue-400" size={16} />
                    <span>DEF: {currentCard.character.def}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gauge className="text-green-400" size={16} />
                    <span>SPD: {currentCard.character.spd}</span>
                  </div>
                </div>
                <div className="mt-2 p-2 bg-gray-700 rounded">
                  <p className="text-xs text-gray-300">
                    <strong>Charge:</strong> {currentCard.charge.name} - {currentCard.charge.effect}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upgrade Section */}
        {currentCard && (
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="text-green-400" size={20} />
                  Upgrade Stats
                </CardTitle>
                <Badge variant="secondary" className="bg-blue-600 text-white">
                  {usedPoints}/{upgradePoints} Points Used
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* HP Upgrade */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="text-red-400" size={16} />
                    <span>HP (+{upgrades.hp * 100})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('hp', -1)}
                      disabled={upgrades.hp <= 0}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{upgrades.hp}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('hp', 1)}
                      disabled={usedPoints >= upgradePoints}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <Progress value={(upgrades.hp / 5) * 100} className="h-2" />
              </div>

              {/* ATK Upgrade */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="text-yellow-400" size={16} />
                    <span>ATK (+{upgrades.atk * 10})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('atk', -1)}
                      disabled={upgrades.atk <= 0}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{upgrades.atk}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('atk', 1)}
                      disabled={usedPoints >= upgradePoints}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <Progress value={(upgrades.atk / 5) * 100} className="h-2" />
              </div>

              {/* DEF Upgrade */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="text-blue-400" size={16} />
                    <span>DEF (+{upgrades.def * 10})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('def', -1)}
                      disabled={upgrades.def <= 0}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{upgrades.def}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('def', 1)}
                      disabled={usedPoints >= upgradePoints}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <Progress value={(upgrades.def / 5) * 100} className="h-2" />
              </div>

              {/* SPD Upgrade */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Gauge className="text-green-400" size={16} />
                    <span>SPD (+{upgrades.spd * 10})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('spd', -1)}
                      disabled={upgrades.spd <= 0}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{upgrades.spd}</span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleUpgrade('spd', 1)}
                      disabled={usedPoints >= upgradePoints}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <Progress value={(upgrades.spd / 5) * 100} className="h-2" />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upgraded Card Preview */}
        {upgradedCard && usedPoints > 0 && (
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Upgraded Card Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-gray-800 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold text-white">{upgradedCard.character.name}</h3>
                  <Badge variant="secondary" className={`text-xs ${getRarityBadgeColor(upgradedCard.character.rarity)} text-white`}>
                    {upgradedCard.character.rarity}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Activity className="text-red-400" size={16} />
                    <span>HP: {upgradedCard.character.hp}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="text-yellow-400" size={16} />
                    <span>ATK: {upgradedCard.character.atk}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="text-blue-400" size={16} />
                    <span>DEF: {upgradedCard.character.def}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gauge className="text-green-400" size={16} />
                    <span>SPD: {upgradedCard.character.spd}</span>
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={handleWriteNFC} 
                className="w-full mt-4 bg-green-600 hover:bg-green-700"
                disabled={isWritingNFC}
              >
                {isWritingNFC ? "Writing to NFC..." : "Write Upgraded Card to NFC"}
              </Button>
              {forceNFC && (
                <p className="text-xs text-orange-400 mt-2">
                  🚀 Force mode enabled - attempting NFC write regardless of browser support
                </p>
              )}
              

            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}