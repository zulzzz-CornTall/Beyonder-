import { useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { NFCScanner } from "@/components/ui/nfc-scanner";
import { CardDisplay } from "@/components/ui/card-display";
import { X, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { parseNFC, isValidNFC, nfcToCard } from "@/lib/nfc-utils";

export default function Scanner() {
  const [scannedCard, setScannedCard] = useState(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const isBattleMode = searchParams.includes('battle=true');

  const scanMutation = useMutation({
    mutationFn: async (cardData: any) => {
      console.log('Sending card data to server:', cardData);
      const response = await apiRequest("POST", "/api/scan", {
        barcode: cardData.barcode,
        name: cardData.name,
        hp: cardData.hp,
        attack: cardData.attack,
        defense: cardData.defense,
        speed: cardData.speed,
        description: cardData.description,
        rarity: cardData.rarity,
        imageUrl: cardData.imageUrl,
        version: cardData.version,
        userId: 1 // Mock user ID
      });
      return response.json();
    },
    onSuccess: (data) => {
      setScannedCard(data.card);
      
      if (isBattleMode) {
        toast({
          title: "Card Ready for Battle!",
          description: `${data.card.name} is ready to fight!`,
        });
        // Store scanned card in localStorage for battle
        localStorage.setItem('battleCard', JSON.stringify(data.card));
        // Redirect to battle after 2 seconds
        setTimeout(() => {
          setLocation('/battle');
        }, 2000);
      } else {
        toast({
          title: "Card Scanned!",
          description: `Added ${data.card.name} to your collection`,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/users/1/cards'] });
      }
    },
    onError: (error) => {
      toast({
        title: "Scan Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleNFCScan = (nfcText: string) => {
    const nfcData = parseNFC(nfcText);
    if (!nfcData) {
      toast({
        title: "Invalid NFC Data",
        description: "The NFC data format is invalid. Please check the card format.",
        variant: "destructive",
      });
      return;
    }
    
    const cardData = nfcToCard(nfcData);
    scanMutation.mutate(cardData);
  };

  const handleScanError = (error: string) => {
    toast({
      title: "Scanner Error",
      description: error,
      variant: "destructive"
    });
  };

  return (
    <div className="min-h-screen bg-game-dark text-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-purple-900 p-6">
        <div className="flex items-center justify-between">
          <Link to={isBattleMode ? "/matchmaking" : "/"} className="text-white">
            <Button variant="ghost" size="sm" className="w-10 h-10 rounded-full bg-black/50">
              <X className="text-white" size={20} />
            </Button>
          </Link>
          <div className="text-center">
            <h2 className="font-orbitron font-bold text-lg text-white">
              {isBattleMode ? 'SCAN BATTLE CARD' : 'NFC SCANNER'}
            </h2>
            <p className="text-sm text-gray-300">
              {isBattleMode ? 'Scan your character card to enter battle' : 'Scan your NFC card to add to collection'}
            </p>
          </div>
          <div className="w-10 h-10"></div>
        </div>
      </div>

      {/* Scanner Content */}
      <div className="p-6">
        {!scannedCard ? (
          <NFCScanner
            onScan={handleNFCScan}
            onError={handleScanError}
          />
        ) : (
          /* Success Card Display */
          <div className="flex flex-col items-center space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {isBattleMode ? 'Ready for Battle!' : 'Card Added!'}
              </h3>
              <p className="text-gray-300">
                {isBattleMode ? 'Redirecting to battle...' : 'Card successfully added to collection'}
              </p>
            </div>
            
            <CardDisplay 
              card={scannedCard} 
              size="medium" 
              showStats={true}
              className="mb-6"
            />
            
            {!isBattleMode && (
              <div className="flex space-x-3">
                <Button 
                  onClick={() => setScannedCard(null)}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Scan Another
                </Button>
                <Link to="/" className="flex-1">
                  <Button variant="outline" className="w-full">
                    Done
                  </Button>
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}