import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CardDisplay } from "@/components/ui/card-display";
import { X, Plus } from "lucide-react";
import type { Card as CardType } from "@shared/schema";

export default function CardList() {
  const { data: playerCards, isLoading } = useQuery({
    queryKey: ['/api/users/1/cards'],
    enabled: false // Using mock data for now
  });

  // Start with empty collection - cards only added when scanned
  const mockScannedCards: any[] = [];

  const scannedCards = mockScannedCards;
  
  const characters = scannedCards.filter(item => item.card.type === "C");

  return (
    <div className="min-h-screen bg-game-dark text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-game-secondary border-b border-electric-blue/20">
        <h2 className="font-orbitron font-bold text-2xl text-electric-blue">MY CARDS</h2>
        <Link href="/">
          <Button variant="ghost" size="sm" className="w-10 h-10 rounded-full bg-game-accent">
            <X className="text-gray-400" size={20} />
          </Button>
        </Link>
      </div>

      <div className="p-4 space-y-6">
        {/* Characters Section */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-orbitron font-bold text-lg text-electric-blue">
              CHARACTERS ({characters.length})
            </h3>
            <Link href="/scanner">
              <Button size="sm" className="bg-electric-blue hover:bg-electric-blue/80">
                <Plus size={16} className="mr-1" />
                Scan
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {characters.map((item) => (
              <Card key={item.id} className="card-holographic">
                <CardContent className="p-4">
                  <CardDisplay card={item.card} showQuantity={item.quantity} />
                </CardContent>
              </Card>
            ))}
            {characters.length === 0 && (
              <div className="col-span-2 text-center py-8 text-gray-400">
                <p>No character cards scanned yet</p>
              </div>
            )}
          </div>
        </div>



        {/* Battle Ready Check */}
        {characters.length >= 1 && (
          <Card className="bg-gradient-to-r from-electric-blue/20 to-purple-glow/20 border border-electric-blue/50">
            <CardContent className="p-4 text-center">
              <h3 className="font-orbitron font-bold text-lg text-electric-blue mb-2">
                BATTLE READY!
              </h3>
              <p className="text-sm text-gray-300 mb-4">
                You have a character card ready for battle
              </p>
              <Link href="/matchmaking">
                <Button className="bg-electric-blue hover:bg-electric-blue/80 font-orbitron font-bold">
                  START BATTLE
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {characters.length < 1 && (
          <Card className="bg-game-secondary border border-warning-orange/50">
            <CardContent className="p-4 text-center">
              <h3 className="font-orbitron font-bold text-lg text-warning-orange mb-2">
                NEED CHARACTER CARD
              </h3>
              <p className="text-sm text-gray-300 mb-4">
                You need at least 1 Character card to battle
              </p>
              <div className="flex justify-center space-x-4 text-sm">
                <span className={characters.length >= 1 ? "text-neon-green" : "text-warning-orange"}>
                  Characters: {characters.length}/1
                </span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}