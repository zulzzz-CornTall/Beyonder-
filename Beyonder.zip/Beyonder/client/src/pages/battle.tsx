import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CardDisplay } from "@/components/ui/card-display";
import { Badge } from "@/components/ui/badge";
import { NFCScanner } from "@/components/ui/nfc-scanner";
import { Header } from "@/components/ui/header";
import { ArrowLeft, Zap, Shield, Star, User, Users, Sword, Heart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { parseNFC, nfcToCard } from "@/lib/nfc-utils";
import type { Card as CardType } from "@shared/schema";

interface BattleState {
  player1: {
    character: CardType | null;
    currentHp: number;
    powerUsed: boolean;
    specialCharging: boolean;
    specialTurns: number;
    blocked: boolean;
  };
  player2: {
    character: CardType | null;
    currentHp: number;
    powerUsed: boolean;
    specialCharging: boolean;
    specialTurns: number;
    blocked: boolean;
  };
  currentPlayer: 1 | 2;
  winner: string | null;
  turn: number;
  phase: "setup" | "battle" | "finished";
  setupStep: "player1" | "player2" | "ready";
}

export default function Battle() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const battleMode = new URLSearchParams(searchParams).get('mode') || 'local';
  
  const [battleState, setBattleState] = useState<BattleState>({
    player1: {
      character: null,
      currentHp: 0,
      powerUsed: false,
      specialCharging: false,
      specialTurns: 0,
      blocked: false
    },
    player2: {
      character: null,
      currentHp: 0,
      powerUsed: false,
      specialCharging: false,
      specialTurns: 0,
      blocked: false
    },
    currentPlayer: 1,
    winner: null,
    turn: 1,
    phase: "setup",
    setupStep: "player1"
  });

  const [isScanning, setIsScanning] = useState(false);

  const handleNFCScan = (nfcText: string) => {
    const nfcData = parseNFC(nfcText);
    if (!nfcData) {
      toast({
        title: "Invalid NFC Card",
        description: "Could not read card data. Please try again.",
        variant: "destructive"
      });
      return;
    }

    const cardData = nfcToCard(nfcData);
    
    if (battleState.setupStep === "player1") {
      setBattleState(prev => ({
        ...prev,
        player1: {
          ...prev.player1,
          character: cardData,
          currentHp: cardData.hp
        },
        setupStep: "player2"
      }));
      
      toast({
        title: "Player 1 Ready!",
        description: `${cardData.name} is ready for battle`,
      });
    } else if (battleState.setupStep === "player2") {
      setBattleState(prev => ({
        ...prev,
        player2: {
          ...prev.player2,
          character: cardData,
          currentHp: cardData.hp
        },
        setupStep: "ready"
      }));
      
      toast({
        title: "Player 2 Ready!",
        description: `${cardData.name} is ready for battle`,
      });
    }
    
    setIsScanning(false);
  };

  const handleNFCError = (error: string) => {
    toast({
      title: "NFC Error",
      description: error,
      variant: "destructive"
    });
    setIsScanning(false);
  };

  const startBattle = () => {
    if (!battleState.player1.character || !battleState.player2.character) return;
    
    // Determine who goes first based on speed
    const player1Speed = battleState.player1.character.speed;
    const player2Speed = battleState.player2.character.speed;
    
    setBattleState(prev => ({
      ...prev,
      phase: "battle",
      currentPlayer: player1Speed >= player2Speed ? 1 : 2
    }));
    
    toast({
      title: "Battle Begins!",
      description: `Player ${player1Speed >= player2Speed ? 1 : 2} goes first (Speed: ${Math.max(player1Speed, player2Speed)})`,
    });
  };

  const performAction = (action: "attack" | "power" | "special") => {
    const currentPlayerData = battleState.currentPlayer === 1 ? battleState.player1 : battleState.player2;
    const opponentData = battleState.currentPlayer === 1 ? battleState.player2 : battleState.player1;
    
    if (!currentPlayerData.character || !opponentData.character) return;

    let damage = 0;
    let actionDescription = "";

    switch (action) {
      case "attack":
        // Charge attack - main attack from NFC charge section (no charging required)
        damage = Math.max(1, currentPlayerData.character.attack - opponentData.character.defense);
        const chargeEffect = currentPlayerData.character.charge?.effect || "Deal damage based on ATK stat";
        actionDescription = `${currentPlayerData.character.name} uses ${currentPlayerData.character.charge?.name || "Charge Attack"} for ${damage} damage! (${chargeEffect})`;
        break;
      case "power":
        if (currentPlayerData.powerUsed) {
          toast({
            title: "Power Already Used",
            description: "You can only use Power once per battle",
            variant: "destructive"
          });
          return;
        }
        // Block opponent's next attack
        setBattleState(prev => ({
          ...prev,
          [battleState.currentPlayer === 1 ? "player1" : "player2"]: {
            ...currentPlayerData,
            powerUsed: true
          },
          [battleState.currentPlayer === 1 ? "player2" : "player1"]: {
            ...opponentData,
            blocked: true
          }
        }));
        actionDescription = `${currentPlayerData.character.name} uses Power Block! Opponent's next attack will be blocked.`;
        break;
      case "special":
        // Special attack - requires charging (from NFC special section)
        if (currentPlayerData.specialCharging && currentPlayerData.specialTurns <= 1) {
          // Execute special attack based on effect
          const specialEffect = currentPlayerData.character.special?.effect || "Deal 30% of opponent's max HP as damage";
          
          if (specialEffect.includes("30% of opponent's max HP")) {
            damage = Math.floor(opponentData.character.hp * 0.3);
          } else if (specialEffect.includes("40% of opponent's max HP")) {
            damage = Math.floor(opponentData.character.hp * 0.4);
          } else if (specialEffect.includes("50% of opponent's max HP")) {
            damage = Math.floor(opponentData.character.hp * 0.5);
          } else {
            // Default special damage
            damage = Math.floor(currentPlayerData.character.attack * 1.8);
          }
          
          setBattleState(prev => ({
            ...prev,
            [battleState.currentPlayer === 1 ? "player1" : "player2"]: {
              ...currentPlayerData,
              specialCharging: false,
              specialTurns: 0
            }
          }));
          
          const specialName = currentPlayerData.character.special?.name || "Special Attack";
          actionDescription = `${currentPlayerData.character.name} unleashes ${specialName} for ${damage} damage! (${specialEffect})`;
        } else if (!currentPlayerData.specialCharging) {
          // Start charging special
          setBattleState(prev => ({
            ...prev,
            [battleState.currentPlayer === 1 ? "player1" : "player2"]: {
              ...currentPlayerData,
              specialCharging: true,
              specialTurns: 3
            }
          }));
          const specialName = currentPlayerData.character.special?.name || "Special Attack";
          actionDescription = `${currentPlayerData.character.name} begins charging ${specialName} (3 turns remaining)`;
        } else {
          // Continue charging
          const specialName = currentPlayerData.character.special?.name || "Special Attack";
          actionDescription = `${currentPlayerData.character.name} continues charging ${specialName}... (${currentPlayerData.specialTurns - 1} turns remaining)`;
        }
        break;
    }

    // Apply damage if not blocked
    if (damage > 0 && !opponentData.blocked) {
      const newHp = Math.max(0, opponentData.currentHp - damage);
      
      setBattleState(prev => ({
        ...prev,
        [battleState.currentPlayer === 1 ? "player2" : "player1"]: {
          ...opponentData,
          currentHp: newHp,
          blocked: false
        },
        winner: newHp <= 0 ? `Player ${battleState.currentPlayer}` : null,
        phase: newHp <= 0 ? "finished" : "battle"
      }));
    } else if (opponentData.blocked && action === "attack") {
      setBattleState(prev => ({
        ...prev,
        [battleState.currentPlayer === 1 ? "player2" : "player1"]: {
          ...opponentData,
          blocked: false
        }
      }));
      actionDescription += " But it was blocked!";
    }

    // Update special charging countdown
    if (currentPlayerData.specialCharging && currentPlayerData.specialTurns > 1) {
      setBattleState(prev => ({
        ...prev,
        [battleState.currentPlayer === 1 ? "player1" : "player2"]: {
          ...currentPlayerData,
          specialTurns: currentPlayerData.specialTurns - 1
        }
      }));
    }

    // Switch turns
    setBattleState(prev => ({
      ...prev,
      currentPlayer: prev.currentPlayer === 1 ? 2 : 1,
      turn: prev.turn + 1
    }));

    toast({
      title: `Player ${battleState.currentPlayer}'s Turn`,
      description: actionDescription,
    });
  };

  const resetBattle = () => {
    setBattleState({
      player1: {
        character: null,
        currentHp: 0,
        powerUsed: false,
        specialCharging: false,
        specialTurns: 0,
        blocked: false
      },
      player2: {
        character: null,
        currentHp: 0,
        powerUsed: false,
        specialCharging: false,
        specialTurns: 0,
        blocked: false
      },
      currentPlayer: 1,
      winner: null,
      turn: 1,
      phase: "setup",
      setupStep: "player1"
    });
  };

  return (
    <div className="min-h-screen bg-game-dark text-white">
      <Header 
        title={battleMode === 'local' ? 'LOCAL BATTLE' : 'ONLINE BATTLE'}
        subtitle={battleState.phase === "setup" ? "Card Setup" : 
                  battleState.phase === "battle" ? `Turn ${battleState.turn}` : "Battle Finished"}
        showBack={true}
        backUrl="/matchmaking"
      />

      <div className="p-6 space-y-6">
        {/* Setup Phase */}
        {battleState.phase === "setup" && (
          <>
            {/* Current Setup Step */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Users className="text-electric-blue" size={20} />
                  Battle Setup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  {battleState.setupStep === "player1" && (
                    <div>
                      <h3 className="text-lg font-bold text-electric-blue mb-2">Player 1</h3>
                      <p className="text-gray-300 mb-4">Scan your character card to enter battle</p>
                    </div>
                  )}
                  {battleState.setupStep === "player2" && (
                    <div>
                      <h3 className="text-lg font-bold text-purple-400 mb-2">Player 2</h3>
                      <p className="text-gray-300 mb-4">Scan your character card to enter battle</p>
                    </div>
                  )}
                  {battleState.setupStep === "ready" && (
                    <div>
                      <h3 className="text-lg font-bold text-green-400 mb-2">Both Players Ready!</h3>
                      <p className="text-gray-300 mb-4">Click Start Battle to begin</p>
                    </div>
                  )}
                </div>

                {battleState.setupStep !== "ready" && (
                  <div className="space-y-2">
                    <Button
                      onClick={() => setIsScanning(true)}
                      disabled={isScanning}
                      className="w-full bg-gradient-to-r from-electric-blue to-purple-600 hover:from-blue-600 hover:to-purple-700 h-12"
                    >
                      {isScanning ? "Scanning..." : "Scan Card"}
                    </Button>
                    

                  </div>
                )}

                {battleState.setupStep === "ready" && (
                  <Button
                    onClick={startBattle}
                    className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 h-12"
                  >
                    Start Battle
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Player Cards Display */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Player 1 */}
              <Card className={`bg-gray-900 ${battleState.player1.character ? 'border-electric-blue' : 'border-gray-700'}`}>
                <CardHeader>
                  <CardTitle className="text-electric-blue">Player 1</CardTitle>
                </CardHeader>
                <CardContent>
                  {battleState.player1.character ? (
                    <CardDisplay card={battleState.player1.character} size="medium" />
                  ) : (
                    <div className="h-44 bg-gray-800 rounded-lg flex items-center justify-center">
                      <p className="text-gray-400">Waiting for card...</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Player 2 */}
              <Card className={`bg-gray-900 ${battleState.player2.character ? 'border-purple-400' : 'border-gray-700'}`}>
                <CardHeader>
                  <CardTitle className="text-purple-400">Player 2</CardTitle>
                </CardHeader>
                <CardContent>
                  {battleState.player2.character ? (
                    <CardDisplay card={battleState.player2.character} size="medium" />
                  ) : (
                    <div className="h-44 bg-gray-800 rounded-lg flex items-center justify-center">
                      <p className="text-gray-400">Waiting for card...</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </>
        )}

        {/* Battle Phase */}
        {battleState.phase === "battle" && (
          <>
            {/* Current Turn Indicator */}
            <Card className="bg-gray-900 border-yellow-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Sword className="text-yellow-400" size={20} />
                  Player {battleState.currentPlayer}'s Turn
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Choose your action:</p>
              </CardContent>
            </Card>

            {/* Player Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Player 1 Status */}
              <Card className={`bg-gray-900 ${battleState.currentPlayer === 1 ? 'border-electric-blue' : 'border-gray-700'}`}>
                <CardHeader>
                  <CardTitle className="text-electric-blue flex items-center justify-between">
                    Player 1
                    {battleState.player1.blocked && <Badge variant="outline" className="text-blue-400">Blocked</Badge>}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {battleState.player1.character && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">HP:</span>
                        <span className="font-bold text-neon-green">
                          {battleState.player1.currentHp}/{battleState.player1.character.hp}
                        </span>
                      </div>
                      <Progress 
                        value={(battleState.player1.currentHp / battleState.player1.character.hp) * 100} 
                        className="h-2"
                      />
                      <div className="text-xs text-gray-400">
                        {battleState.player1.specialCharging && (
                          <div>Charging: {battleState.player1.specialTurns} turns remaining</div>
                        )}
                        {battleState.player1.powerUsed && <div>Power used</div>}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Player 2 Status */}
              <Card className={`bg-gray-900 ${battleState.currentPlayer === 2 ? 'border-purple-400' : 'border-gray-700'}`}>
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center justify-between">
                    Player 2
                    {battleState.player2.blocked && <Badge variant="outline" className="text-blue-400">Blocked</Badge>}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {battleState.player2.character && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">HP:</span>
                        <span className="font-bold text-neon-green">
                          {battleState.player2.currentHp}/{battleState.player2.character.hp}
                        </span>
                      </div>
                      <Progress 
                        value={(battleState.player2.currentHp / battleState.player2.character.hp) * 100} 
                        className="h-2"
                      />
                      <div className="text-xs text-gray-400">
                        {battleState.player2.specialCharging && (
                          <div>Charging: {battleState.player2.specialTurns} turns remaining</div>
                        )}
                        {battleState.player2.powerUsed && <div>Power used</div>}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Action Buttons */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <Button
                    onClick={() => performAction("attack")}
                    className="bg-red-600 hover:bg-red-700 h-16"
                  >
                    <div className="text-center">
                      <Sword className="mx-auto mb-1" size={20} />
                      <div className="text-xs">Charge Attack</div>
                    </div>
                  </Button>
                  
                  <Button
                    onClick={() => performAction("power")}
                    disabled={battleState.currentPlayer === 1 ? battleState.player1.powerUsed : battleState.player2.powerUsed}
                    className="bg-blue-600 hover:bg-blue-700 h-16 disabled:bg-gray-700"
                  >
                    <div className="text-center">
                      <Shield className="mx-auto mb-1" size={20} />
                      <div className="text-xs">Power Block</div>
                    </div>
                  </Button>
                  
                  <Button
                    onClick={() => performAction("special")}
                    className="bg-purple-600 hover:bg-purple-700 h-16"
                  >
                    <div className="text-center">
                      <Star className="mx-auto mb-1" size={20} />
                      <div className="text-xs">
                        {(battleState.currentPlayer === 1 ? battleState.player1.specialCharging : battleState.player2.specialCharging)
                          ? "Special Attack" : "Charge Special"}
                      </div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* Battle Finished */}
        {battleState.phase === "finished" && battleState.winner && (
          <Card className="bg-gray-900 border-green-700 border-2">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Star className="text-gold-accent" size={20} />
                Battle Complete!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gold-accent mb-2">
                  {battleState.winner} Wins!
                </h2>
                <p className="text-gray-300">
                  Victory earned! You can now upgrade your character cards.
                </p>
              </div>
              
              <div className="flex gap-4">
                <Button
                  onClick={resetBattle}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Battle Again
                </Button>
                <Button
                  onClick={() => setLocation("/upgrade")}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Upgrade Cards
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* NFC Scanner Modal */}
      {isScanning && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="bg-gray-900 border-gray-700 w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <User className="text-electric-blue" size={20} />
                Scan {battleState.setupStep === "player1" ? "Player 1" : "Player 2"} Card
              </CardTitle>
            </CardHeader>
            <CardContent>
              <NFCScanner 
                onScan={handleNFCScan}
                onError={handleNFCError}
              />
              <Button
                onClick={() => setIsScanning(false)}
                variant="outline"
                className="w-full mt-4"
              >
                Cancel
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}