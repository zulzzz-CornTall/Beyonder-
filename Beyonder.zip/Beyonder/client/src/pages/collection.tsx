import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CardDisplay } from "@/components/ui/card-display";
import { X, Search } from "lucide-react";
import { useState } from "react";
import type { Card as CardType } from "@shared/schema";

export default function Collection() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("all");

  const { data: playerCards, isLoading } = useQuery({
    queryKey: ['/api/users/1/cards']
  });

  // Mock collection data
  const mockCards = [
    {
      id: 1,
      card: {
        id: 1,
        name: "DragonFire",
        type: "C",
        version: "001",
        attack: 85,
        defense: 60,
        energy: 80,
        rarity: "legendary",
        barcode: "C=DragonFire_001",
        description: "A legendary dragon with devastating fire attacks"
      },
      quantity: 1
    },
    {
      id: 2,
      card: {
        id: 2,
        name: "Guardian",
        type: "C",
        version: "001",
        attack: 45,
        defense: 90,
        energy: 60,
        rarity: "rare",
        barcode: "C=Guardian_001",
        description: "A defensive warrior with unbreakable shield"
      },
      quantity: 2
    },
    {
      id: 3,
      card: {
        id: 3,
        name: "FireBlast",
        type: "P",
        version: "002",
        attack: 40,
        defense: 0,
        energy: 30,
        rarity: "common",
        barcode: "P=FireBlast_002",
        description: "A powerful fire attack that burns enemies"
      },
      quantity: 3
    },
    {
      id: 4,
      card: {
        id: 4,
        name: "EnergyBoost",
        type: "CG",
        version: "001",
        attack: 0,
        defense: 0,
        energy: 50,
        rarity: "common",
        barcode: "CG=EnergyBoost_001",
        description: "Increases energy for next turn"
      },
      quantity: 1
    },
    {
      id: 5,
      card: {
        id: 5,
        name: "UltimateStrike",
        type: "S",
        version: "001",
        attack: 100,
        defense: 0,
        energy: 80,
        rarity: "legendary",
        barcode: "S=UltimateStrike_001",
        description: "A devastating attack that can end battles"
      },
      quantity: 1
    }
  ];

  const collection = playerCards || mockCards;

  const filteredCards = collection.filter(item => {
    const matchesSearch = item.card.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === "all" || item.card.type === selectedType;
    return matchesSearch && matchesType;
  });

  const stats = {
    characters: collection.filter(item => item.card.type === "C").length,
    powers: collection.filter(item => item.card.type === "P").length,
    charges: collection.filter(item => item.card.type === "CG").length,
    specials: collection.filter(item => item.card.type === "S").length,
    total: collection.reduce((sum, item) => sum + item.quantity, 0)
  };

  return (
    <div className="min-h-screen bg-game-dark text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-game-secondary border-b border-electric-blue/20">
        <h2 className="font-orbitron font-bold text-2xl text-electric-blue">MY COLLECTION</h2>
        <Link href="/">
          <Button variant="ghost" size="sm" className="w-10 h-10 rounded-full bg-game-accent">
            <X className="text-gray-400" size={20} />
          </Button>
        </Link>
      </div>

      <div className="p-4 space-y-6">
        {/* Collection Stats */}
        <div className="grid grid-cols-4 gap-3">
          <Card className="bg-game-secondary">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-orbitron font-bold text-electric-blue">{stats.characters}</p>
              <p className="text-xs text-gray-400">Characters</p>
            </CardContent>
          </Card>
          <Card className="bg-game-secondary">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-orbitron font-bold text-purple-glow">{stats.powers}</p>
              <p className="text-xs text-gray-400">Powers</p>
            </CardContent>
          </Card>
          <Card className="bg-game-secondary">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-orbitron font-bold text-warning-orange">{stats.charges}</p>
              <p className="text-xs text-gray-400">Charges</p>
            </CardContent>
          </Card>
          <Card className="bg-game-secondary">
            <CardContent className="p-3 text-center">
              <p className="text-2xl font-orbitron font-bold text-gold-accent">{stats.specials}</p>
              <p className="text-xs text-gray-400">Specials</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card className="bg-game-secondary">
          <CardContent className="p-4 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <Input
                placeholder="Search cards..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-game-accent border-electric-blue/20 text-white"
              />
            </div>
            <div className="flex space-x-2">
              {[
                { value: "all", label: "All" },
                { value: "C", label: "Characters" },
                { value: "P", label: "Powers" },
                { value: "CG", label: "Charges" },
                { value: "S", label: "Specials" }
              ].map(type => (
                <Button
                  key={type.value}
                  variant={selectedType === type.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedType(type.value)}
                  className={selectedType === type.value ? "bg-electric-blue" : "border-electric-blue/20"}
                >
                  {type.label}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Card Grid */}
        <div className="grid grid-cols-2 gap-4">
          {filteredCards.map((item) => (
            <Card key={item.id} className="card-holographic hover:scale-105 transition-transform cursor-pointer">
              <CardContent className="p-4">
                <CardDisplay card={item.card} showQuantity={item.quantity} />
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCards.length === 0 && (
          <Card className="bg-game-secondary">
            <CardContent className="p-8 text-center">
              <p className="text-gray-400">No cards found matching your search.</p>
              <Link href="/scanner">
                <Button className="mt-4 bg-electric-blue hover:bg-electric-blue/80">
                  Scan More Cards
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
